var searchData=
[
  ['cramerove_5fpravidlo_1',['Cramerove_pravidlo',['../namespace_cramerove__pravidlo.html',1,'']]]
];
