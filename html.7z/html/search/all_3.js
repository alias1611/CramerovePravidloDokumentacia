var searchData=
[
  ['hlavná_20stránka_3',['Hlavná stránka',['../index.html',1,'']]]
];
