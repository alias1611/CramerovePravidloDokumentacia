var searchData=
[
  ['hlavná_20stránka_15',['Hlavná stránka',['../index.html',1,'']]]
];
